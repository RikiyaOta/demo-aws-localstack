export const handler = async (event, context) => {
  return "Hello! This is create-user function!";
};

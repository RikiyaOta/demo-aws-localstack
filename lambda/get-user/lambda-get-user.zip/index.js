export const handler = async (event, context) => {
  return "Hello! This is get-user function!";
};
